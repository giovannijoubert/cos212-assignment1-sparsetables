import java.util.Random;

public class Main
{
	/*Use this class to test your implementation.  This file will be overwritten for marking purposes.*/
	
	private static void printSchedule(Schedule mySchedule){
		String Line = "\t";
		for (int i = 0; i < 7; i++) {
			Line = Line+"\t"+mySchedule.rootDayIndex[i];
		}
		System.out.println(Line);
		Event printMe;
		for (int i = 0; i < 33; i++) {
			Line = "("+i+")\t" +mySchedule.rootTimeIndex[i];
			for (int j = 0; j < 7; j++) {
				printMe = mySchedule.getEvent(mySchedule.rootTimeIndex[i], mySchedule.rootDayIndex[j]);
				if(printMe == null){
					Line = Line + "\t" + "*";
				} else {
					Line = Line + "\t" + printMe.getDescription();
				}
				
			}
			System.out.println(Line);
		}

	}

	public static void main(String[] args)
	{
		
		//Write code to test your implementation here.
		Schedule mySchedule = new Schedule();

		// MANUALLY ADDING EVENTS
		System.out.println();
		mySchedule.addEvent("08:30", "thu", "Dentist");
	
		System.out.println(mySchedule.getEvent("08:30", "thu").getDescription());

		mySchedule.addEvent("09:00", "mon", "COS 212");

		System.out.println(mySchedule.getEvent("09:00", "mon").getDescription());

		mySchedule.addEvent("09:30", "sun", "Church");

		System.out.println(mySchedule.getEvent("09:30", "sun").getDescription());

		mySchedule.addEvent("09:00", "wed", "Cycling");

		System.out.println(mySchedule.findEvent("Cycling").getDescription());

	
		
	/* generating randomly
		int number = new Random().nextInt(5 - 1 + 1) + 1;
		int day = new Random().nextInt(6 - 0 + 1) + 0;
		int time = new Random().nextInt(32 - 0 + 1) + 0;
		number = number*30;
		Integer counter = 0;
			for(int j = 0; j < 15; j++){
				number = new Random().nextInt(5 - 1 + 1) + 1;
				number = number*30;
				day = new Random().nextInt(6 - 0 + 1) + 0;
				time = new Random().nextInt(32 - 0 + 1) + 0;
				mySchedule.addEvent(mySchedule.rootTimeIndex[time], mySchedule.rootDayIndex[day], counter.toString(),number);
				counter++;
			} */
		
			String queryTime = "09:00";
		//	System.out.println();
		//	System.out.println("\t Time Printout: "+queryTime);
			Event timeTransverse = mySchedule.getTimeEvent(queryTime);
			String Line = "";
			while(timeTransverse != null){
				Line = Line + timeTransverse.getDescription() + ",";
				timeTransverse = timeTransverse.right;
				}
				System.out.println(Line);

				mySchedule.addEvent("18:30", "sun", "Liturgy");

			System.out.println(mySchedule.findEvent("Liturgy").getDescription());

		String queryDay = "sun";
		Line = "";
		Event Transverse = mySchedule.getDayEvent(queryDay);
		while(Transverse.down !=  mySchedule.getDayEvent(queryDay)) {
			Line = Line + Transverse.getDescription() + ",";
			Transverse = Transverse.down;
		}
		Line = Line + Transverse.getDescription() + ",";
		System.out.println(Line); 

		System.out.println(mySchedule.getDayEvent(queryDay).up.getDescription()+","+mySchedule.getDayEvent(queryDay).getDescription()); 


		mySchedule.addEvent("09:30", "wed", "Breakfast");
		System.out.println(mySchedule.getEvent("09:30", "wed").getDescription());

	

		String queryDay2 = "wed";
		Line = "";
		Event Transverse2 = mySchedule.getDayEvent(queryDay2);
		while(Transverse2.down !=  mySchedule.getDayEvent(queryDay2)) {
			Line = Line + Transverse2.getDescription() + ",";
			Transverse2 = Transverse2.down;
		}
		Line = Line + Transverse2.getDescription() + ",";
		System.out.println(Line); 


		String queryDay3 = "wed";
		Line = "";
		Event Transverse3 = mySchedule.getDayEvent(queryDay3).up;
		while(Transverse3.up !=  mySchedule.getDayEvent(queryDay3).up) {
			Line = Line + Transverse3.getDescription() + ",";
			Transverse3 = Transverse3.up;
		}
		Line = Line + Transverse3.getDescription() + ",";
		System.out.println(Line); 


		String queryTime2 = "09:30";
		//	System.out.println();
		//	System.out.println("\t Time Printout: "+queryTime);
			Event timeTransverse2 = mySchedule.getTimeEvent(queryTime2);
			String Line2 = "";
			while(timeTransverse2 != null){
				Line2 = Line2 + timeTransverse2.getDescription() + ",";
				timeTransverse2 = timeTransverse2.right;
				}
				System.out.println(Line2);

				mySchedule.addEvent("09:00", "tue", "Prac");

				String queryTime3 = "09:00";
		//	System.out.println();
		//	System.out.println("\t Time Printout: "+queryTime);
			Event timeTransverse3 = mySchedule.getTimeEvent(queryTime3);
			String Line3 = "";
			while(timeTransverse3 != null){
				Line3 = Line3 + timeTransverse3.getDescription() + ",";
				timeTransverse3 = timeTransverse3.right;
				}
				System.out.println(Line3);

				mySchedule.addEvent("09:30", "tue", "Lecture");

				String queryDay5 = "tue";
		Line = "";
		Event Transverse4 = mySchedule.getDayEvent(queryDay5);
		while(Transverse4.down !=  mySchedule.getDayEvent(queryDay5)) {
			Line = Line + Transverse4.getDescription() + ",";
			Transverse4 = Transverse4.down;
		}
		Line = Line + Transverse4.getDescription() + ",";
		System.out.println(Line); 

		String queryDay6 = "tue";
		Line = "";
		Event Transverse6 = mySchedule.getDayEvent(queryDay6).up;
		while(Transverse6.up !=  mySchedule.getDayEvent(queryDay6).up) {
			Line = Line + Transverse6.getDescription() + ",";
			Transverse6 = Transverse6.up;
		}
		Line = Line + Transverse6.getDescription() + ",";
		System.out.println(Line); 

		mySchedule.addEvent("17:00", "wed", "Shopping");

		String queryDay7 = "wed";
		Line = "";
		Event Transverse5 = mySchedule.getDayEvent(queryDay7);
		while(Transverse5.down !=  mySchedule.getDayEvent(queryDay7)) {
			Line = Line + Transverse5.getDescription() + ",";
			Transverse5 = Transverse5.down;
		}
		Line = Line + Transverse5.getDescription() + ",";
		System.out.println(Line); 


		String queryDay8 = "wed";
		Line = "";
		Event Transverse7 = mySchedule.getDayEvent(queryDay8).up;
		while(Transverse7.up !=  mySchedule.getDayEvent(queryDay8).up) {
			Line = Line + Transverse7.getDescription() + ",";
			Transverse7 = Transverse7.up;
		}
		Line = Line + Transverse7.getDescription() + ",";
		System.out.println(Line); 

		mySchedule.addEvent("17:00", "mon", "Date");


		String queryTime4 = "17:00";
		//	System.out.println();
		//	System.out.println("\t Time Printout: "+queryTime);
			Event timeTransverse4 = mySchedule.getTimeEvent(queryTime4);
			String Line5 = "";
			while(timeTransverse4 != null){
				Line5 = Line5 + timeTransverse4.getDescription() + ",";
				timeTransverse4 = timeTransverse4.right;
				}
				System.out.println(Line5);

				

				mySchedule.addEvent("17:00", "tue", "Nap");


				String queryTime5 = "17:00";
		//	System.out.println();
		//	System.out.println("\t Time Printout: "+queryTime);
			Event timeTransverse5 = mySchedule.getTimeEvent(queryTime5);
			String Line6 = "";
			while(timeTransverse5 != null){
				Line6 = Line6 + timeTransverse5.getDescription() + ",";
				timeTransverse5 = timeTransverse5.right;
				}
				System.out.println(Line6);



				String queryDay10 = "tue";
		Line = "";
		Event Transverse8 = mySchedule.getDayEvent(queryDay10);
		while(Transverse8.down !=  mySchedule.getDayEvent(queryDay10)) {
			Line = Line + Transverse8.getDescription() + ",";
			Transverse8 = Transverse8.down;
		}
		Line = Line + Transverse8.getDescription() + ",";
		System.out.println(Line); 


		String queryDay9 = "tue";
		Line = "";
		Event Transverse9 = mySchedule.getDayEvent(queryDay9).up;
		while(Transverse9.up !=  mySchedule.getDayEvent(queryDay9).up) {
			Line = Line + Transverse9.getDescription() + ",";
			Transverse9 = Transverse9.up;
		}
		Line = Line + Transverse9.getDescription() + ",";
		System.out.println(Line); 


		mySchedule.addEvent("16:00", "mon", "Exam",120);

		mySchedule.clearByTime("09:00");

		String queryDay11 = "mon";
		Line = "";
		Event Transverse11 = mySchedule.getDayEvent(queryDay11);
		while(Transverse11.down !=  mySchedule.getDayEvent(queryDay11)) {
			Line = Line + Transverse11.getDescription() + ",";
			Transverse11 = Transverse11.down;
		}
		Line = Line + Transverse11.getDescription() + ",";
		System.out.println(Line); 


		String queryDay12 = "mon";
		Line = "";
		Event Transverse12 = mySchedule.getDayEvent(queryDay12).up;
		while(Transverse12.up !=  mySchedule.getDayEvent(queryDay12).up) {
			Line = Line + Transverse12.getDescription() + ",";
			Transverse12 = Transverse12.up;
		}
		Line = Line + Transverse12.getDescription() + ",";
		System.out.println(Line); 


		mySchedule.clearByDay("tue");

		String queryTime10 = "09:00";
		//	System.out.println();
			Event timeTransverse15 = mySchedule.getTimeEvent(queryTime10);
			String Line61 = "";
			while(timeTransverse15 != null){
				Line61 = Line61 + timeTransverse15.getDescription() + ",";
				timeTransverse15 = timeTransverse15.right;
				}
				System.out.println(Line61);




		System.out.println();





		
     	printSchedule(mySchedule);
	}

	
	
}
